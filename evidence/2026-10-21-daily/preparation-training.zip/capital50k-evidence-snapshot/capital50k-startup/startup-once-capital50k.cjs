'use strict';
// One-time orchestration for the preregistered virtual research window.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{spawn}=require('node:child_process');
const base=__dirname,policy=JSON.parse(fs.readFileSync(path.join(base,'startup-policy-capital50k.json'))),release=JSON.parse(fs.readFileSync(path.join(base,'startup-manifest-capital50k.json')));
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),write=(name,data)=>fs.writeFileSync(path.join(base,name),JSON.stringify(data,null,2),{flag:'wx'}),stamp=()=>new Date().toISOString();
if(sha(__filename)!==release.bootstrapHash||sha(path.join(base,'startup-policy-capital50k.json'))!==release.policyHash)throw Error('Startup orchestration fingerprint changed');
const staging=policy.staging,source=path.join(staging,'source'),D=require(path.join(source,'scripts/paired-forward-monitor.js')),Audit=require(path.join(source,'assets/audit-identity.js'));
if(Audit.hash(D.sourceHashes(source))!==Audit.hash(release.sourceHashes))throw Error('Frozen preparation source mismatch');
write('readiness-scheduler-capital50k.claim',{at:stamp(),pid:process.pid,policyHash:release.policyHash,kind:'startup_schedule_only_no_account'});
const waitUntil=async time=>{while(Date.now()<time)await new Promise(r=>setTimeout(r,Math.min(30000,time-Date.now())));};
async function main(){
 if(Date.now()>=Date.parse(policy.declarationDeadline)){write('startup-expired.json',{at:stamp(),reason:'declaration_deadline_already_passed',accountCreated:false});return;}
 for(let i=0;i<policy.probes.length;i++){
  await waitUntil(Date.parse(policy.probes[i]));if(Date.now()>=Date.parse(policy.declarationDeadline))break;
  const output=path.join(base,'native-open-probe-'+(i+1));let check;
  try{check=await D.preflight({root:source,output,helper:path.join(staging,'market-transport.exe'),nativeDescriptor:path.join(staging,'gate.json'),nativeSources:path.join(staging,'native-sources'),modelArtifact:path.join(staging,'model-artifact.json'),testLog:path.join(staging,'formal-tests.log'),testVerification:path.join(base,'formal-test-verification-capital50k-final.json')});write('probe-'+(i+1)+'-result.json',{at:stamp(),...check});}
  catch(e){write('probe-'+(i+1)+'-failure.json',{at:stamp(),error:e.stack,accountCreated:false});continue;}
  if(!check.nativeEntryReady)continue;
  if(Date.now()>=Date.parse(policy.declarationDeadline)){write('startup-late-after-proof.json',{at:stamp(),check,accountCreated:false});return;}
  const prepared=D.prepare({root:source,stableRoot:policy.stableRoot,id:policy.id,capitalProfile:policy.capitalProfile,entryAfter:policy.entryAfter,latestEntry:policy.latestEntry,gateFile:check.gateFile,helper:path.join(staging,'market-transport.exe'),modelArtifact:path.join(staging,'model-artifact.json')});
  write('future-declaration-created.json',{at:stamp(),directory:prepared.directory,manifestHash:Audit.hash(prepared.manifest),policyHash:release.policyHash,entryAfter:policy.entryAfter,latestEntry:policy.latestEntry,newAccountCreated:false});
  const script=path.join(prepared.directory,'source/scripts/paired-forward-monitor.js'),out=fs.openSync(path.join(base,'paired-monitor.out.log'),'wx'),err=fs.openSync(path.join(base,'paired-monitor.err.log'),'wx');
  const child=spawn(process.execPath,[script,'--run','--directory',prepared.directory,'--until',policy.until],{cwd:prepared.directory,detached:true,windowsHide:true,stdio:['ignore',out,err]});fs.closeSync(out);fs.closeSync(err);child.unref();
  write('paired-monitor-launch.json',{at:stamp(),pid:child.pid,script,scriptHash:sha(script),directory:prepared.directory,until:policy.until,command:'--run (virtual only)',noCapitalReset:true});return;
 }
 write('startup-not-ready.json',{at:stamp(),reason:'fixed_native_readiness_probes_did_not_pass_in_time',newAccountCreated:false,noBackfill:true});
}
main().catch(e=>{write('startup-failure-'+Date.now()+'.json',{at:stamp(),error:e.stack,newAccountCreated:false});process.exitCode=1;});
